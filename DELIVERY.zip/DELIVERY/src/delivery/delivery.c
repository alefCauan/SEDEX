#include "delivery.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> 
#include <errno.h>
#include <time.h>
#include <unistd.h>


int id_delivery = 0;
int total_score = 0;
////////////////////////////////////////////////////////////////////////////////
/////////////////////////// FUNÇÕES DE ENTREGA /////////////////////////////////

// verifica se o stack está vazio
BOOL is_empty(Deliveries *deliveries)
{
    return deliveries->top == NULL;
}

void undelivered_push(Deliveries *deliveries, Route_node *route_node) 
{
    Deliveries_node *new_node = (Deliveries_node *)malloc(sizeof(Deliveries_node));
    check_allocation(new_node, "Deliveries node");

    new_node->route_node = route_node;
    new_node->next = deliveries->top;
    deliveries->top = new_node;

    printf("PEDIDO (%s) DE %s EM %s ADICIONADO A ROTA DE NÃO EFETUADAS\n", new_node->route_node->item.name, new_node->route_node->client->name, new_node->route_node->client->address);
    line();
}

// Remover Entrega Não Efetuada da Pilha
Deliveries_node *undelivered_pop(Deliveries_node *deliveries)
{  
    if(deliveries)
    {
        Deliveries_node *removed = deliveries;
        deliveries = removed->next;
        // free_node_deliveries(removed);
        return deliveries;
    }

    return deliveries;
}
// Listar Entregas Não Efetuadas
void list_unfulfilled_deliveries(Deliveries *deliveries)
{
    Deliveries_node *aux = deliveries->top;
    if (aux==NULL)
        printf("A lista de não entregues esta vazia!");
    
    printf("Lista de entregas não efetuadas:\n");
    while (aux!=NULL)
    {
        print_client(*deliveries->top->route_node->client);
        aux = aux->next;
    }

    free_node_deliveries(aux);
}

////////////////////////////////////////////////////////////////////////////////
/////////////////////////// FUNÇÕES DE DEVOLUÇÃO ///////////////////////////////

// Adicionar Devolução na Fila
void add_devolution(Devolution *devolution, Deliveries *deliveries) 
{
    // fprintf(stderr, "Stack de deliveries está vazio\n");
    if (is_empty(deliveries)) 
        return;

    while (!is_empty(deliveries) && deliveries->top->route_node) 
    {
        Route_node *route_node = deliveries->top->route_node;

        // Aloca um novo nó de devolução
        Devolution_node *new_node = alloc_node_devolution();
        check_allocation(new_node, "Devolution node");
        new_node->route = route_node;

        if (!devolution->start) 
        {
            devolution->start = new_node;
            devolution->end = new_node;
        } 
        else 
        {
            devolution->end->next = new_node;
            devolution->end = new_node;
        }

        deliveries->top = deliveries->top->next;
    }
}

// Remover Devolução da Fila
void remove_devolution(Devolution *devolution) 
{
    if (devolution->start == NULL) 
    {
        printf("Nenhuma devolução para remover.\n");
        return;
    }

    Devolution_node *removed = devolution->start;
    devolution->start = removed->next;
    
    if (devolution->start == NULL) 
        devolution->end = NULL;

    free_node_devolution(removed);
    printf("Devolução removida com sucesso.\n");
}



// faz a listagem de todas as devoluções 
void list_devolutions(Devolution *devolution) 
{
    if (devolution == NULL || devolution->start == NULL) 
    {
        printf("Nenhum pedido foi movido para devolução!\n");
        return;
    }

    Devolution_node *current = devolution->start;

    printf("\n----- LISTA DE DEVOLUÇÕES -----\n");

    while (current != NULL) {
        // Verificação de NULL para current->route
        if (current->route == NULL) {
            printf("Erro: Rota não definida para a devolução!\n");
            current = current->next;
            continue;  // Pula para o próximo nó
        }

        // Verificação de NULL para current->route->client
        Client *client = current->route->client;
        if (client == NULL || client->id_client == 0) { // Adicionando uma verificação adicional
            printf("Erro: Cliente não definido para a devolução!\n");
            current = current->next;
            continue;  // Pula para o próximo nó
        }

        // Acessa as informações do cliente e do item com segurança
        Itens item = current->route->item;

        // Imprime os dados do cliente e do item
        printf("ID Cliente:   %d\n", client->id_client);
        printf("Nome Cliente: %s\n", client->name);
        printf("Endereço:     %s\n", client->address);
        printf("Produto:      %s\n", item.name);
        printf("Preço:        %.2f\n", item.price);
        printf("---------------------------------\n");

        // Avança para o próximo nó na lista
        current = current->next;
    }
}

// Verifica se um evento vai acontecer ou não
BOOL random_event(Odds odd) 
{
    int choice = random_choice(1, 100);
    return choice <= (int)odd;
}

// Calcular o score ao entregar ou na devolução
void score_calc_event(Score score) 
{
    total_score += score;
}

// Evento de rota, uma pessoa realiza um pedido
void route_event(Route *route, Client *client) 
{
    if(random_event(LOW_MID))
        add_delivery_route(route, client);
}
      
Route_node *next(Route_node *route) 
{
    if (!route)
        return route;

    route = route->next;
    return route;
}

void verify_next_client(Client *previous, Client *next, int *chances, Odds odd)
{
    if(odd > 0 && (previous->id_client == next->id_client || strcmp(previous->address, next->address) == 0))
    {
        sleep(0.2);
        *chances = 100;
    }
    else 
    {
        sleep(random_choice(1, 2));
        *chances = odd;
    }
}

void verify_next_client_stack(Client *previous, Client *next, int *chances, Odds odd)
{
    if(odd > 0 && (previous->id_client == next->id_client || strcmp(previous->address, next->address) == 0))
    {
        sleep(0.2);
        *chances = 0;
    }
    else 
    {
        sleep(random_choice(1, 2));
        *chances = odd;
    }
}

// Evento que verifica se a pessoa estava em casa
void home_delivery_event(Route *route, Deliveries *deliveries, Devolution *devolution) 
{
    // Primeira tentativa
    printf("\n-- REALIZANDO A PRIMEIRA TENTATIVA DE ENTREGA --\n\n");
    Route_node *aux_route = route->start;
    Route_node *prev_route = NULL;

    int chances = MID_HIGH;

    // sleep(1);
    while (aux_route) 
    {
        if (random_event(chances)) 
        {
            if(aux_route->next)
                verify_next_client(aux_route->client, aux_route->next->client, &chances, MID_HIGH);

            printf("PEDIDO (%s) ENTREGUE PARA %s no endereço %s [SCORE +5]\n", aux_route->item.name, aux_route->client->name, aux_route->client->address);
            line();
            score_calc_event(DELIVERY_FIRST);
            
            // Remover o nó atual da rota
            if (prev_route == NULL) 
                route->start = aux_route->next;
            else 
                prev_route->next = aux_route->next;

            // Avançar para o próximo nó e liberar o atual
            Route_node *temp = aux_route;
            aux_route = aux_route->next;
            free_node_route(temp);
        } 
        else 
        {
            if(aux_route->next)
                verify_next_client_stack(aux_route->client, aux_route->next->client, &chances, MID_HIGH);

            aux_route->attempts += 1;
            undelivered_push(deliveries, aux_route);
            
            prev_route = aux_route;
            aux_route = aux_route->next;
        }
    }
    printf("\n-- FINALIZANDO A PRIMEIRA TENTATIVA DE ENTREGA --\n");

    sleep(1.5);

    printf("\n--- INICIANDO A SEGUNDA TENTATIVA DE ENTREGA ---\n\n");
    // Segunda tentativa
    chances = HIGH;
    Deliveries_node *aux_deli = deliveries->top;
    Deliveries_node *prev_deli = NULL;

    while (aux_deli != NULL) 
    {
        if (random_event(chances)) 
        {
            if(aux_deli->next)
                verify_next_client(aux_deli->route_node->client, aux_deli->next->route_node->client, &chances, HIGH);

            printf("PEDIDO (%s) ENTREGUE PARA %s NO ENDEREÇO %s [SCORE +3]\n", 
            aux_deli->route_node->item.name, 
            aux_deli->route_node->client->name, 
            aux_deli->route_node->client->address);
            score_calc_event(DELIVERY_SECOND);
            line();

            // Remover o nó atual da pilha de entregas
            Deliveries_node *temp_deli = aux_deli;
            aux_deli = aux_deli->next;

            if (prev_deli == NULL)
                deliveries->top = aux_deli;
            else 
                prev_deli->next = aux_deli;

            // Remover o nó da rota associado
            if (temp_deli->route_node != NULL)
                free_node_route(temp_deli->route_node);

            free_node_deliveries(temp_deli);
        } 
        else 
        {
            if(aux_deli->next)
                verify_next_client_stack(aux_deli->route_node->client, aux_deli->next->route_node->client, &chances, HIGH);

            printf("PEDIDO (%s) DE %s NO ENDEREÇO %s MOVIDO PARA DEVOLUÇÃO [SCORE -1]\n", aux_deli->route_node->item.name, aux_deli->route_node->client->name, aux_deli->route_node->client->address);
            aux_deli->route_node->attempts += 1;
            line();
            add_devolution(devolution, deliveries);
            score_calc_event(DELIVERY_DEVOLUTION);
            
            prev_deli = aux_deli;
            aux_deli = aux_deli->next;
        }
    }

    // Garantir que todas as estruturas estejam vazias ao final
    route->start = NULL;
    deliveries->top = NULL;

    printf("\n--- FINALIZANDO A SEGUNDA TENTATIVA DE ENTREGA ---\n");
}

void main_menu(Client *client, Route *route, Deliveries *deliveries, Devolution *devolution)
{
    Aux aux = {0};

    do {
        do
        {
            printf("\n--------- MENU DE ENTREGAS ----------\n");
            printf("1 - CADASTRAR CLIENTE\n");
            printf("2 - REMOVER CLINTE\n");
            printf("3 - LISTAR CLIENTE\n");
            printf("4 - ABRIR PARA PEDIDOS\n");
            printf("5 - REALIZAR ROTA DE ENTREGA\n");
            printf("6 - LISTAR DEVOLUÇÕES\n");
            printf("0 - SAIR\n");
            printf("----------- [SCORE: %3d] ------------\n", total_score);
            printf("Escolha uma opção -> ");
            scanf("%d", &aux.opt);
        }
        while(!valid_answer(0, 6, aux.opt));
        
        printf("\n");

        if(aux.opt == 0) return;

        switch (aux.opt)
        {
            case 1:
                client_register(client);
                break;
            case 2:
                client_removal(client);
                break;
            case 3:
                client_list(client);
                break;
            case 4:
                if(route->start != NULL) 
                {
                    printf("\nOs pedidos do dia já estão cadastrados, realize a entrega\n");
                    break;
                }
                int interval_seconds = 10;  // Ajuste o intervalo conforme necessário
                // Tempo de início
                time_t start_time = time(NULL);

                while (TRUE) 
                {
                    route_event(route, client->next);
                    if (difftime(time(NULL), start_time) >= interval_seconds) 
                    {
                        start_time = time(NULL);
                        break;
                    }

                    usleep(100000);  // Pausa de 100 milissegundos
                }
                break;
            case 5:
                if(route->start == NULL) 
                {
                    printf("\nNão há entregas para serem feitas\n");
                    break;
                }
                home_delivery_event(route, deliveries, devolution);
                break;
            case 6:
                list_devolutions(devolution);
                break;
            default:
                printf("Opção inválida! Tente novamente.\n");
        }
    } 
    while (aux.opt != 0);
}


void init_operation()
{
    initialize_random();

    // criação de rota
    Route *route = alloc_route();
    // criação de pilha de entregas não efetuadas
    Deliveries *deliveries = alloc_deliveries();
    // criação de fila de devoluções
    Devolution *devolution = alloc_devolution();
    // criação de clientes
    Client *clients = alloc_client();

    // cont_client += 6;
    // id_delivery += 6;
    initialize_clients(clients);

    main_menu(clients, route, deliveries, devolution);

    // int interval_seconds = 10;  // Ajuste o intervalo conforme necessário

    // // Tempo de início
    // time_t start_time = time(NULL);

    // while (TRUE) 
    // {
    //     // Executa a função route_event
    //     route_event(route, clients->next);

    //     // Verifica se o intervalo de tempo passou
    //     if (difftime(time(NULL), start_time) >= interval_seconds) 
    //     {
    //         // Executa a função home_delivery_event
    //         home_delivery_event(route, deliveries, devolution);
    //         // Atualiza o tempo de início para o próximo intervalo
    //         start_time = time(NULL);
    //         break;
    //     }

    //     // Adiciona uma pequena pausa para evitar alta utilização da CPU
    //     usleep(100000);  // Pausa de 100 milissegundos
    // }

    printf("final score = %d\n", total_score);
    free_route(route);
    free_deliveries(deliveries);
    free_devolution(devolution);
    free_client(clients);
}


