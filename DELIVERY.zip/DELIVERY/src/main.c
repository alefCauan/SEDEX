#include "delivery.h"
// #include "delivery/delivery.c"
 

int main() 
{
    init_operation();

    return 0;
}
